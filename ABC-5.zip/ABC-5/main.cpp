#include <iostream>
#include <thread>
#include <mutex>
#include <vector>
#include <string>

class Grandson;

class Input {
public:
    double sum_;
    double *portions_;

    std::mutex mutex_;
};

class Output {
public:
    double *money_;
    std::mutex mutex_;
};

int grandsons_count;
Grandson **heirs;

Input input;
Output output;

// Class, implementing heirs functionality.
class Grandson {
public:
    explicit Grandson(int id) {
        id_ = id;

        workflow_ = nullptr;
    }

    void countMoney() {
        // Getting input.
        double portion = getPortion();

        // Counting.
        input.mutex_.lock();
        double money = input.sum_ * portion;
        input.mutex_.unlock();
        std::cout << "Brother #" + std::to_string(id_) + " calculated his amount of money\n";

        // Setting output.
        setMoney(money);
    }

    int id_;

    // Each person has their own thread.
    std::thread* workflow_;

private:
    double getPortion() {
        std::lock_guard<std::mutex> guard(input.mutex_);
        double portion = input.portions_[id_];

        std::cout << "Brother #" + std::to_string(id_) + " has got his portion\n";

        return portion;
    }

    void setMoney(double money) {
        std::lock_guard<std::mutex> guard(output.mutex_);
        output.money_[id_] = money;

        std::cout << "Brother #" + std::to_string(id_) + " has set his amount of money\n";
    }
};

void threadFunction(Grandson *heir) {
    heir->countMoney();
}

int main(int argc, char **argv) {
    grandsons_count = 4;

    if (argc != grandsons_count + 2) {
        std::cout << (grandsons_count + 1) << " arguments should be provided";
        return 1;
    }

    // Creating people (I'm something of god myself).
    heirs = new Grandson*[grandsons_count];
    for (int i = 0; i < grandsons_count; ++i) {
        heirs[i] = new Grandson(i);
    }

    input.portions_ = new double[grandsons_count];
    output.money_ = new double [grandsons_count];

    /*
     * Here we parse portions, create people,
     * do all the calculations and print the results in parallel.
     */
    input.sum_ = atof(argv[1]);
    if (input.sum_ <= 0) {
        std::cout << "Sum should be greater then zero.";
        return 1;
    }

    double portionsSum = 0;
    for (int i = 0; i < grandsons_count; ++i) {
        // Getting input.
        double newPortion = atof(argv[i + 2]);
        input.portions_[i] = newPortion;
        portionsSum += newPortion;

        if ((newPortion < 0.01) || (newPortion > 1)) {
            std::cout << "Portions are incorrect\n";
            return 1;
        }

        // Making calculations.
        heirs[i]->workflow_ = new std::thread(threadFunction, heirs[i]);
    }

    if (portionsSum != 1) {
        std::cout << "Sum of portions should be equal to 1\n";
        return 0;
    }

    // Stating to print output in parallel.
    std::cout << "Money of:\n";
    for (int i = 0; i < grandsons_count; ++i) {
        heirs[i]->workflow_->join();
        std::cout << "<<Brother #" + std::to_string(i) + ">> - " + std::to_string(output.money_[i]) + "\n";
    }

    // Cleaning memory.
    delete[] heirs;
    delete[] input.portions_;
    delete[] output.money_;

    return 0;
}
