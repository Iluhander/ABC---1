import math


# Class representing complex numbers.
class ComplexNumber(object):
    def __init__(self, real, imaginary):
        self.real = real
        self.imaginary = imaginary

    def print(self, file_stream):
        file_stream.write("(Complex; " + str(self.real) + ", " + str(self.imaginary) + "; Function value: " + str(self.cast_to_double()) + ")")

    # Method returning polar number value.
    def cast_to_double(self):
        return math.sqrt(self.real * self.real + self.imaginary * self.imaginary)
