import Rand
import FractionNumber as fracNum
import PolarNumber as polarNum
import ComplexNumber as complexNum


# Class representing
class Container(object):
    def __init__(self):
        self.size = 0

        self.elements = []

    # Method for printing elements.
    def print(self, file_name):
        file_stream = open(file_name, 'w')

        file_stream.write("Elements count: " + str(self.size) + "\n")
        file_stream.write("Current average value: " + str(self.get_average_value()) + "\n\n")

        try:
            for i in range(0, self.size):
                self.elements[i].print(file_stream)
                file_stream.write("\n")

        finally:
            file_stream.close()

    # Method for reading file.
    def in_file(self, file_name):
        with open(file_name) as in_file:
            contents = in_file.read().replace("\n", " ").replace("  ", " ").split(" ")

        self.size = int(contents[0])
        i = 1
        while i < len(contents):
            if contents[i] == "complex":
                self.elements.append(complexNum.ComplexNumber(float(contents[i + 1]), float(contents[i + 2])))
            elif contents[i] == "polar":
                self.elements.append(polarNum.PolarNumber(float(contents[i + 1]), float(contents[i + 2])))
            else:
                self.elements.append(fracNum.FractionNumber(int(contents[i + 1]), int(contents[i + 2])))

            i = i + 3

    # Method for randomly setting container's elements.
    def in_rand(self, new_size):
        self.size = int(new_size)
        self.elements = []
        for i in range(0, self.size):
            self.elements.append(Rand.get_random_number())

    # Method calculating the average value of the collection's elements
    def get_average_value(self):
        elements_sum = 0
        for i in range(0, self.size):
            elements_sum += self.elements[i].cast_to_double()

        return elements_sum / self.size

    # Method returning only elements with values not less then average
    def remove_less_then_average(self):
        average_value = self.get_average_value()

        amount = 0
        for i in range(0, self.size):
            if self.elements[i].cast_to_double() >= average_value:
                amount = amount + 1

        result = []
        for i in range(0, self.size):
            if self.elements[i].cast_to_double() >= average_value:
                result.append(self.elements[i])

        self.elements = result
        self.size = amount
