# Class representing fraction numbers.
class FractionNumber(object):
    def __init__(self, numerator, denominator):
        self.numerator = numerator
        self.denominator = denominator

    def print(self, file_stream):
        file_stream.write("(Fraction; " + str(self.numerator) + "/" + str(self.denominator) + "; Function value: " + str(self.cast_to_double()) + ")")

    # Method returning fraction number value.
    def cast_to_double(self):
        return self.numerator / self.denominator
