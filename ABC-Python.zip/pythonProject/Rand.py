import random
import math
import random as rnd
import FractionNumber as fracNum
import PolarNumber as polarNum
import ComplexNumber as complexNum


# Method creating new random number.
def get_random_number():
    number_type = random.randint(1, 3)

    if number_type == 1:
        numerator = random.randint(-10000, 10000)
        denominator = random.randint(1, 10000)

        return fracNum.FractionNumber(numerator, denominator)
    elif number_type == 2:
        angle = random.random() * 2 * 3.14
        radius = random.randint(1, 10000)

        return polarNum.PolarNumber(angle, radius)
    else:
        real = random.randint(-10000, 10000)
        imaginary = random.randint(-10000, 10000)

        return complexNum.ComplexNumber(real, imaginary)

