import math


# Class representing polar numbers.
class PolarNumber(object):
    def __init__(self, radius, angle):
        self.angle = angle
        self.radius = radius

    def print(self, file_stream):
        file_stream.write("(Polar; " + str(self.radius) + ", " + str(self.angle) + "; Function value: " + str(self.cast_to_double()) + ")")

    # Method returning polar number value.
    def cast_to_double(self):
        return self.radius / math.cos(self.angle)
