import sys
import string
import time

import Container as container

start_time = round(time.time() * 1000)

if __name__ == '__main__':
    # If this variable change it's value, it means that user chose random input.
    elements_amount = -1
    if (len(sys.argv) == 5) and (sys.argv[1] == "-f"):
        input_file_name = sys.argv[2]
        output_file1_name = sys.argv[3]
        output_file2_name = sys.argv[4]
    elif (len(sys.argv) == 5) and (sys.argv[1] == "-n"):
        elements_amount = sys.argv[2]
        output_file1_name = sys.argv[3]
        output_file2_name = sys.argv[4]
    else:
        print("Incorrect command line!\n"
              "You must write:\n"
              "python main -f input.txt output1.txt output2.txt\n"
              "or\n"
              "python main -n n output1.txt output2.txt")
        exit()

    print('Start')

    # Creating and filling the container
    elements = container.Container()

    if elements_amount == -1:
        elements.in_file(input_file_name)
    else:
        elements.in_rand(elements_amount)

    # Printing current condition.
    elements.print(output_file1_name)

    # Applying the function given.
    elements.remove_less_then_average()

    # Printing container after applying the function.
    elements.print(output_file2_name)

    delta_time = round(time.time() * 1000) - start_time
    print('Finish. Time spent: ' + str(delta_time))
